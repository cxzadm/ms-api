const config = {
    PORT: 3001, 
    DB_URL: 'mongodb+srv://batemp789:VNR4OOO5HmNj73UD@cluster0.53zhvqu.mongodb.net/?retryWrites=true&w=majority'

}

module.exports = config